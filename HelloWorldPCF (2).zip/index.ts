import {IInputs, IOutputs} from "./generated/ManifestTypes";

export class HelloWorldControl implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private _container: HTMLDivElement;

    constructor() {}

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        this._container = document.createElement("div");
        this._container.innerText = "Hello World from PCF!";
        this._container.style.fontSize = "20px";
        this._container.style.color = "blue";
        container.appendChild(this._container);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {}

    public getOutputs(): IOutputs {
        return {};
    }

    public destroy(): void {}
}